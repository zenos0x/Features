# clipbutton.ps1 - a small always-on-top floating button that opens the Windows
# clipboard history (Win+V) for whatever app you are typing in.
#
# The button window is created with WS_EX_NOACTIVATE, so clicking it never takes
# focus away from your app: the clipboard panel opens at your app's text cursor and
# pastes there. Left-click = open clipboard, drag = move the button, right-click = Exit.
# Runs hidden via clipbutton.vbs; only one instance at a time.

$created = $false
$mutex = New-Object System.Threading.Mutex($false, 'Local\ClipButtonSingleton', [ref]$created)
if (-not $created) { return }

Add-Type -AssemblyName System.Windows.Forms, System.Drawing
Add-Type -ReferencedAssemblies System.Windows.Forms, System.Drawing -TypeDefinition @'
using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
public class NoActivateForm : Form {
    const int WS_EX_NOACTIVATE = 0x08000000, WS_EX_TOOLWINDOW = 0x80, WS_EX_TOPMOST = 0x8;
    const int WM_MOUSEACTIVATE = 0x21, MA_NOACTIVATE = 3;
    protected override bool ShowWithoutActivation { get { return true; } }
    protected override CreateParams CreateParams {
        get { CreateParams cp = base.CreateParams; cp.ExStyle |= WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW | WS_EX_TOPMOST; return cp; }
    }
    protected override void WndProc(ref Message m) {
        if (m.Msg == WM_MOUSEACTIVATE) { m.Result = (IntPtr)MA_NOACTIVATE; return; }
        base.WndProc(ref m);
    }
    [DllImport("user32.dll")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
    [DllImport("shell32.dll", CharSet = CharSet.Auto)] public static extern uint ExtractIconEx(string file, int index, IntPtr[] large, IntPtr[] small, uint n);
    public static void SendWinV() {
        keybd_event(0x5B, 0, 0, UIntPtr.Zero);
        keybd_event(0x56, 0, 0, UIntPtr.Zero);
        System.Threading.Thread.Sleep(30);
        keybd_event(0x56, 0, 2, UIntPtr.Zero);
        keybd_event(0x5B, 0, 2, UIntPtr.Zero);
    }
}
'@

$posFile = Join-Path $PSScriptRoot 'clipbutton.pos'
$size = 44

# clipboard icon from shell32.dll (index 260)
$icon = $null
$handles = New-Object IntPtr[] 1
if ([NoActivateForm]::ExtractIconEx("$env:SystemRoot\System32\shell32.dll", 260, $handles, $null, 1) -gt 0) {
    $icon = [System.Drawing.Icon]::FromHandle($handles[0])
}

$form = New-Object NoActivateForm
$form.FormBorderStyle = 'None'
$form.ShowInTaskbar = $false
$form.TopMost = $true
$form.StartPosition = 'Manual'
$form.Size = New-Object System.Drawing.Size $size, $size
$form.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 245)
$form.Opacity = 0.92

# default position: bottom-right of the primary screen, kept well clear of the taskbar
# and of anything docked at the right edge (drag the button anywhere you like)
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$loc = New-Object System.Drawing.Point ($wa.Right - $size - 80), ($wa.Bottom - $size - 80)
if (Test-Path $posFile) {
    $parts = (Get-Content $posFile -Raw).Trim() -split ','
    if ($parts.Count -eq 2) {
        $p = New-Object System.Drawing.Point ([int]$parts[0]), ([int]$parts[1])
        # only honour a saved spot that is still on some screen
        foreach ($s in [System.Windows.Forms.Screen]::AllScreens) { if ($s.WorkingArea.Contains($p)) { $loc = $p } }
    }
}
$form.Location = $loc

$tip = New-Object System.Windows.Forms.ToolTip
$tip.SetToolTip($form, 'Clipboard history (Win+V). Drag to move, right-click to exit.')

$menu = New-Object System.Windows.Forms.ContextMenuStrip
[void]$menu.Items.Add('Open clipboard', $null, { [NoActivateForm]::SendWinV() })
[void]$menu.Items.Add('Exit', $null, { $form.Close() })
$form.ContextMenuStrip = $menu

$form.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(120, 120, 120)), 1
    $g.DrawRectangle($pen, 0, 0, $size - 1, $size - 1)
    $pen.Dispose()
    if ($icon) { $g.DrawIcon($icon, [int](($size - 32) / 2), [int](($size - 32) / 2)) }
    else { $g.DrawString('CB', $s.Font, [System.Drawing.Brushes]::Black, 10, 14) }
})

# left click = open clipboard; left drag = move the button
$script:dragStart = $null
$script:dragged = $false
$form.Add_MouseDown({
    param($s, $e)
    if ($e.Button -eq 'Left') { $script:dragStart = $e.Location; $script:dragged = $false }
})
$form.Add_MouseMove({
    param($s, $e)
    if ($e.Button -eq 'Left' -and $script:dragStart) {
        $dx = $e.X - $script:dragStart.X; $dy = $e.Y - $script:dragStart.Y
        if ($script:dragged -or [math]::Abs($dx) -gt 4 -or [math]::Abs($dy) -gt 4) {
            $script:dragged = $true
            $form.Location = New-Object System.Drawing.Point ($form.Left + $dx), ($form.Top + $dy)
        }
    }
})
$form.Add_MouseUp({
    param($s, $e)
    if ($e.Button -eq 'Left') {
        if ($script:dragged) { Set-Content $posFile "$($form.Left),$($form.Top)" }
        else { [NoActivateForm]::SendWinV() }
        $script:dragStart = $null; $script:dragged = $false
    }
})

[System.Windows.Forms.Application]::Run($form)
$mutex.ReleaseMutex()
